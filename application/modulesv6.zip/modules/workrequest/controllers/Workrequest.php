<?php
defined('BASEPATH') or exit('No direct script access allowed');

////require_once APPPATH . '/modules/license/controllers/License.php';

class Workrequest extends MX_Controller
{

    public function __construct()
    {
        parent::__construct();
       // $this->load->module('construction/Construction_license');
        $this->load->library('email');
        $this->load->model('request/Request_model');
    }

    private function sendUpdateMail($work) {
        // $this->load->library('encrypt');
        $config = array();
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'smtp.gmail.com';
        $config['smtp_user'] = 'pasit.tiwawongrut@gmail.com';
        $config['smtp_pass'] = 'kk0877722688';
        $config['smtp_port'] = 465;
        $config['smtp_crypto'] = 'ssl';
        $this->email->initialize($config);
        $this->email->set_mailtype("html");
        $this->email->set_newline("\r\n");

        $this->email->from('pasit.tiwawongrut@gmail.com', 'Identification');
        $this->email->to($work['staff_email']);
        $this->email->subject('อัพเดทสถานะงาน');
        $this->email->message('งาน '.$work['work_name'].' ได้รับการอัพเดทสถานะเป็น '.$work['work_status_name']);
        $this->email->send();
    }

    private function sendApproveMail($work, $status) {
        // $this->load->library('encrypt');
        $config = array();
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'smtp.gmail.com';
        $config['smtp_user'] = 'pasit.tiwawongrut@gmail.com';
        $config['smtp_pass'] = 'kk0877722688';
        $config['smtp_port'] = 465;
        $config['smtp_crypto'] = 'ssl';
        $this->email->initialize($config);
        $this->email->set_mailtype("html");
        $this->email->set_newline("\r\n");

        $this->email->from('pasit.tiwawongrut@gmail.com', 'Identification');
        $this->email->to($work['staff_email']);
        $this->email->subject('อัพเดทสถานะงาน');
        if($status == 1) {
            $this->email->message('งาน '.$work['work_name'].' ได้รับการอนุมัติแล้ว');
        }
        else {
            $this->email->message('งาน '.$work['work_name'].' ไม่ผ่านการอนุมัติแล้ว');
        }
        $this->email->send();
    }

    public function index()
    {
        $worklist = $this->Request_model->getWorkList();
        if (count($worklist) > 0) {
            $data['worklist'] = $worklist;
        }
        else {
            $data['worklist'] = array();
        }
        //echo json_encode($worklist);
        $data['content'] = "workrequest/workrequest";
        $this->load->view('header/index', $data);
    }


    public function viewWorkRequest($id)
    {
        $data['staffList'] = $this->Request_model->getListRepairStaff();
        $data['work'] = $this->Request_model->getWorkByID($id)[0];
        $data['statusList'] = $this->Request_model->getWorkStatusList();
        if ($data['work']['work_status'] == '1') {
            $data['staff'] = $this->Request_model->getUserDepartment($data['work']['staff_id'])[0];
        }
        $data['imageList'] = $this->Request_model->getImageByWorkID($id);
        $data['work_id'] = $id;
        $data['content'] = "workrequest/viewWorkRequest";
        // $data['duedate'] = $date[8].$date[9].'/'.$date[5].$date[6].'/'.$date[0].$date[1].$date[2].$date[3];
        $this->load->view('header/index', $data);
    }
     
    public function approveWorkRequestForm() {
        if ($this->input->post('work_status') == 1) {
            $date = DateTime::createFromFormat('d/m/Y', $this->input->post('duedate'));
            $formData = array(
                'work_id' => $this->input->post('work_id'),
                'duedate' => $date->format('Y-m-d'),
                'work_status' => $this->input->post('work_status'),
                'status_id' => 2,
                'staff_id'=> $this->input->post('staff_id'),
                'work_detail' =>$this->input->post('work_detail')
            );
            $status = '1';
        }
        else {
            $formData = array(
                'work_id' => $this->input->post('work_id'),
                'work_status' => $this->input->post('work_status'),
            );
            $status = '2';
        }
        //echo $formData['duedate'];
        $work = $this->Request_model->getWorkByID($this->input->post('work_id'))[0];
        $this->sendApproveMail($work, $status);
        $this->Request_model->editWork($formData);
        $page = 'workrequest';
        redirect($page);    
    }

    public function updateWorkStatusForm() {
        $formData = array(
            'work_id' => $this->input->post('work_id'),
            'status_id' => $this->input->post('status_id')
        );
        $this->Request_model->editWork($formData);
        $work = $this->Request_model->getWorkByID($this->input->post('work_id'))[0];
        $this->sendUpdateMail($work);
        $page = 'workrequest';
        redirect($page);
    }

    public function staffWorkList() {
        $worklist = $this->Request_model->getWorkListByStaffID($this->session->userdata('staff_id'));
        if (count($worklist) > 0) {
            $data['worklist'] = $worklist;
        }
        else {
            $data['worklist'] = array();
        }
        //echo json_encode($worklist);
        $data['content'] = "workrequest/workrequest";
        $this->load->view('header/index', $data);
    }

    public function staffWorkListByID($id) {
        $worklist = $this->Request_model->getWorkListByStaffID($id);
        if (count($worklist) > 0) {
            $data['worklist'] = $worklist;
        }
        else {
            $data['worklist'] = array();
        }
        //echo json_encode($worklist);
        $data['content'] = "workrequest/workrequest";
        $this->load->view('header/index', $data);
    }

    public function staffWorkListByMonth($month) {
        $data['month'] = $month;
        $data['month_list']=array('มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม','มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม');
        $data['year_list']=array('2010', '2011', '2012', '2013', '2014','2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023','2024','2025','2026','2027','2028','2029','2030','2031','2032');
        $worklist = $this->Request_model->getWorkListByMonth($month);
        if (count($worklist) > 0) {
            $data['worklist'] = $worklist;
        }
        else {
            $data['worklist'] = array();
        }
        //echo json_encode($worklist);
        $data['content'] = "workrequest/workrequestmonth";
        $this->load->view('header/index', $data);
    }

    public function staffWorkListByYear($year) {
        $data['year'] = $year;
        $data['month_list']=array('มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม','มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม');
        $data['year_list']=array('2010', '2011', '2012', '2013', '2014','2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023','2024','2025','2026','2027','2028','2029','2030','2031','2032');
        $worklist = $this->Request_model->getWorkListByYear($year);
        if (count($worklist) > 0) {
            $data['worklist'] = $worklist;
            $done = array(0,0,0,0,0,0,0,0,0,0,0,0);
            $total = array(0,0,0,0,0,0,0,0,0,0,0,0);
            foreach($worklist as $value) {
                $month = $value['inform_date'][5].$value['inform_date'][6];
                $total[(int)$month - 1]++;
                if ($value['percent'] == 100) {
                    $done[(int)$month - 1]++;
                }
            }
        }
        else {
            $done = array(0,0,0,0,0,0,0,0,0,0,0,0);
            $total = array(0,0,0,0,0,0,0,0,0,0,0,0);
            $data['worklist'] = array();
        }
        $data['total'] = $total;
        $data['done'] = $done;
        $data['content'] = "workrequest/workrequestyear";
        $this->load->view('header/index', $data);
    }

    public function staffWorkListReport() {
        $data['worklist'] = $this->Request_model->getWorkStaffReport();
        $data['content'] = "workrequest/reportworklist";
        $this->load->view('header/index', $data);
    }
} //end class
