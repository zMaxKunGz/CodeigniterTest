 
 
    <div id="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <!--Top header start-->
                    <h3 class="ls-top-header">รายละเอียดการแจ้ง</h3>
                    <!--Top header end -->

                    <!--Top breadcrumb start -->
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i></a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">รายละเอียดการแจ้ง</li>
                    </ol>
                    <!--Top breadcrumb start -->
                </div>
            </div>
            <div class="row">
                <div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">รายละเอียดการแจ้ง</h3>
                        </div>
                        <div class="panel-body">

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">เรื่อง</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['work_name']; ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">ผู้แจ้ง</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['staff_name']; ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">อีเมลล์</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['staff_email']; ?></label>
                                        </div>
                                    </div>
                                </div>


                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">เบอร์โทร</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['staff_tel']; ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">รายละเอียดงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['work_description']; ?></label>
                                        </div>
                                    </div>
                                </div>


                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">วันที่แจ้ง</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['inform_date']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">ประเภทการซ่อม</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['problem_name']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">แผนก</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['department_name']; ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">สถานะของงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo ($work['work_status'] == 2) ? 'ไม่อนุมัติ':$work['work_status_name']; ?></label>
                                        </div>
                                    </div>
                                </div> 
                                <?php
                                if ($work['work_status'] == 1) {
                                ?>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">ผู้รับผิดชอบงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $staff['staff_name']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">คำอธิบายงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['work_detail']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">วันที่แล้วเสร็จ</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['duedate'];; ?></label>
                                        </div>
                                    </div>
                                </div> 
                                <?php    
                                }
                                ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <?php
                    if ($this->session->userdata('position_id') == 2 || $this->session->userdata('position_id') == 1) {
                    ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">แก้ไขสถานะงาน</h3>
                        </div>
                        <div class="panel-body">
                            <form id="approveForm" method="post" class="form-horizontal ls_form" action="<?php echo site_url('/workrequest/approveWorkRequestForm/');?>"
                                  enctype="multipart/form-data">
                                <input type="hidden" id="work_status" name="work_status" value="1">
                                <input type="hidden" id="work_id" name="work_id" value="<?php echo $work['work_id']; ?>">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">วันแล้วเสร็จ</label>
                                    <div class="col-lg-9">
                                        <input id="datePickerOnly" class="form-control" type="text" name="duedate" value="<?php echo ($work['duedate'] == null)? $duedate:''; ?>" <?php echo ($work['work_status'] != 0) ? 'disabled':'' ;?>/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">หมอบหมายงาน</label>
                                    <div class="col-lg-9">
                                        <select id="select-staff" class="selectpicker" placeholder="เลือกผู้ปฎิบัติงาน" name="staff_id" <?php echo ($work['work_status'] != 0) ? 'disabled':'' ;?>>
                                            <option></option>
                                            <?php
                                                foreach($staffList as $value) {
                                                    ?>
                                                    <option value="<?php echo $value['staff_id'] ?>" <?php echo ($work['staff_id'] == $value['staff_id'])? 'selected':'' ;?>><?php echo $value['staff_name'] ?></option>
                                                    <?php
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">คำอธิบายงาน</label>

                                    <div class="col-lg-9">
                                        <textarea class="animatedTextArea form-control" id="bio" name="work_detail"
                                                  placeholder="คำอธิบายงาน" <?php echo ($work['work_status'] != 0) ? 'disabled':'' ;?>></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-9 col-lg-offset-3">
                                        <button class="btn btn-success" id="approveButton"  type="button" <?php echo ($work['work_status'] != 0) ? 'disabled':'' ;?>>อนุมัติ</button>
                                    
                                        <button class="btn ls-red-btn"  id="declineButton" type="button" <?php echo ($work['work_status'] != 0) ? 'disabled':'' ;?>>ไม่อนุมัติ</button>
                                    </div>
                                </div>
                            </form>
                            
                        </div>
                    </div>
                    <?php
                    } 
                    if ($this->session->userdata('position_id') == 3 || $this->session->userdata('position_id') == 1) 
                    {
                    ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">แก้ไขสถานะงาน</h3>
                        </div>
                        <div class="panel-body">
                        <form id="updateForm" method="post" class="form-horizontal ls_form" action="<?php echo site_url('/workrequest/updateWorkStatusForm/');?>"
                                  enctype="multipart/form-data">

                                <input type="hidden" id="work_id" name="work_id" value="<?php echo $work['work_id']; ?>">

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">สถานะงาน</label>
                                    <div class="col-lg-9">
                                        <select id="select-status" <?php echo (($work['staff_id'] == $this->session->userdata('staff_id')) && ($work['work_status'] == 1))? '':'disabled'?> class="selectpicker" placeholder="เลือกสถานะ" name="status_id">
                                            <option></option>
                                            <?php
                                                foreach($statusList as $value) {
                                                    ?>
                                                    <option value="<?php echo $value['work_status_id'] ?>"><?php echo $value['work_status_name'] ?></option>
                                                    <?php
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-9 col-lg-offset-3">
                                        <button <?php echo (($work['staff_id'] == $this->session->userdata('staff_id')) && ($work['work_status'] == 1))? '':'disabled'?> class="btn btn-primary" id="updateButton"  type="button">อัพเดทสถานะ</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">รูปภาพ</h3>
                        </div>
                        <div class="panel-body">
                            <?php 
                            foreach ($imageList as $value) {    
                            ?>
                            <div class="col-md-12">
                                <img src="<?php echo base_url($value['image_location'])?>" style="max-width:100%;max-height:100%;">
                            </div> 
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div align="center"><a href="<?php echo site_url('workrequest/index');?>"><button class="btn ls-red-btn"><i class="fa fa-backward"></i> กลับหน้าหลัก </button></a></div>
                </div>
            </div>
            <div class="row">
                <br>
            </div>

        </div>
    </div>



</section>
  
</div>
 <script type="text/javascript">
$("#approveButton").click(function(){
    bootbox.confirm("คุณต้องการอณุมัติงานนี้หรือไม่?", function(result) {
        var data ="Confirm result: "+result;
        if (result) {
            $('#work_status').val('1');
            $('#approveForm').submit();
        }
    });
});

$("#declineButton").click(function(){
    bootbox.confirm("คุณไม่ต้องการอณุมัติงานนี้หรือไม่?", function(result) {
        var data ="Confirm result: "+result;
        if (result) {
            $('#work_status').val('2');
            $('#approveForm').submit();
        }
    });
});

$("#updateButton").click(function(){
    bootbox.confirm("คุณต้องการแก้ไขงานนี้หรือไม่?", function(result) {
        var data ="Confirm result: "+result;
        if (result) {
            $('#updateForm').submit();
        }
    });
});
$(document).ready(function() {
    var $select = $('#select-staff').selectize({
        create: false,
        onChange: eventHandler('onChange'),
        onItemAdd: eventHandler('onItemAdd'),
        onItemRemove: eventHandler('onItemRemove'),
        onOptionAdd: eventHandler('onOptionAdd'),
        onOptionRemove: eventHandler('onOptionRemove'),
        onDropdownOpen: eventHandler('onDropdownOpen'),
        onDropdownClose: eventHandler('onDropdownClose'),
        onInitialize: eventHandler('onInitialize')
    });

    var $select = $('#select-status').selectize({
        create: false,
        onChange: eventHandler('onChange'),
        onItemAdd: eventHandler('onItemAdd'),
        onItemRemove: eventHandler('onItemRemove'),
        onOptionAdd: eventHandler('onOptionAdd'),
        onOptionRemove: eventHandler('onOptionRemove'),
        onDropdownOpen: eventHandler('onDropdownOpen'),
        onDropdownClose: eventHandler('onDropdownClose'),
        onInitialize: eventHandler('onInitialize')
    });

    $('#datePickerOnly').datetimepicker({
        timepicker: false,
        datepicker:true,
        mask:'39/19/9999',
        format:'d/m/Y'
    });
})
</script>
<!--selectize Library start-->
<script src="<?php echo base_url();?>/assets/js/selectize.min.js"></script>
<!--selectize Library End-->
<!-- Date & Time Picker Library Script Start -->
<script src="<?php echo base_url();?>/assets/js/jquery.datetimepicker.js"></script>
<!-- Date & Time Picker Library Script End -->
<!--Select & Tag demo start-->
<script src="<?php echo base_url();?>/assets/js/pages/selectTag.js"></script>
<!--BootBox script for calender start-->
<script src="<?php echo base_url();?>/assets/js/bootbox.min.js"></script>
<!--bootstrap validation Library Script Start-->
<script src="<?php echo base_url();?>assets/js/bootstrapvalidator/bootstrapValidator.js"></script>
<!--bootstrap validation Library Script End-->
