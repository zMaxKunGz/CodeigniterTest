<div class="row">
    <div class="col-md-12 text-right">
        <button type="submit" class="btn btn-success"><i class="fa fa-floppy-o" aria-hidden="true"></i>&nbsp;บันทึกข้อมูล</button>
        <button type="button" data-dismiss="modal" class="btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;ยกเลิก</button>
    </div>
</div>