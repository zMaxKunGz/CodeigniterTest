<ul class="mainNav">
 
    
    <li>
        <a href="<?php echo site_url('request');?>">
            <i class="fa fa-check-square-o"></i><span>รายการแจ้งซ่อม</span>  
        </a>
    </li>
    
    <li class="active">
        <a href="<?php echo site_url('request/register');?>">
            <i class="fa fa-dashboard"></i><span>แจ้งซ่อม</span>
        </a>
    </li>

    <li>
        <a href="<?php  echo site_url('login/logout');?>">
            <i class="glyphicon glyphicon-log-in"></i><span>logout</span>
        </a>
    </li>
</ul>
 