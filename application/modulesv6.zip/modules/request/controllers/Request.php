<?php
defined('BASEPATH') or exit('No direct script access allowed');

////require_once APPPATH . '/modules/license/controllers/License.php';

class Request extends MX_Controller
{

    public function __construct()
    {
        parent::__construct();
       // $this->load->module('construction/Construction_license');
        $this->load->model('request/Request_model');
    }

    public function index()
    {
        $worklist = $this->Request_model->getWorkList();
        if (count($worklist) > 0) {
            $data['worklist'] = $worklist;
        }
        else {
            $data['worklist'] = array();
        }
        //echo json_encode($worklist);
        $data['content'] = "request/allRequest";
        $this->load->view('header/index_register', $data);
    }

    public function register()
    {
        $data['dept_list'] = $this->Request_model->getDept();
        $data['problem_list'] = $this->Request_model->getProblemlist();
        $data['content'] = "request/request";
        $this->load->view('header/index_register', $data);
    }  
    
    public function newRequest() {
        $work = array (
            'work_name'=>$this->input->post('work_name'),
            'work_description'=>$this->input->post('work_detail'),
            'work_name'=>$this->input->post('work_name'),
            'problem_id'=>$this->input->post('problem_id'),
            'status_id'=>1,
            'place_name'=>$this->input->post('place_name'),
            'staff_dept_id'=>$this->session->userdata('staff_dept_id'),
            'work_status'=>0
        );
        $work_id = $this->Request_model->addWorklist($work);
        $this->load->library('upload');
        $dataInfo = array();
        $files = $_FILES;
        $cpt = count($_FILES['userfile']['name']);
        if($_FILES['userfile']['name'][0] != '') {
            for($i=0; $i<$cpt; $i++)
            {           
                $_FILES['userfile']['name']= $files['userfile']['name'][$i];
                $_FILES['userfile']['type']= $files['userfile']['type'][$i];
                $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
                $_FILES['userfile']['error']= $files['userfile']['error'][$i];
                $_FILES['userfile']['size']= $files['userfile']['size'][$i];    

                $file_name = date('Y-m-d').'-'.$work_id.'-'.$i;
                $this->upload->initialize($this->set_upload_options($file_name));
                if ( ! $this->upload->do_upload() )
                {
                    $error = array('error' => $this->upload->display_errors());
                    echo json_encode($error);
                }
                else
                {
                    $dataInfo = $this->upload->data();
                    $imageData[] = array(
                        'work_id'=>$work_id,
                        'image_location'=> 'upload/images/'.$dataInfo['file_name']
                    );
                }
            }
            $this->Request_model->addImage($imageData);
        }
        $page = "request/";
        redirect($page);
    }

    public function viewRequest($id)
    {
        $data['staffList'] = $this->Request_model->getListRepairStaff();
        $data['work'] = $this->Request_model->getWorkByID($id)[0];
        $data['statusList'] = $this->Request_model->getWorkStatusList();
        if ($data['work']['work_status'] == '1') {
            $data['staff'] = $this->Request_model->getUserDepartment($data['work']['staff_id'])[0];
        }
        $data['imageList'] = $this->Request_model->getImageByWorkID($id);
        $data['content'] = "request/viewRequest";
        $this->load->view('header/index_register', $data);
    }  

    private function set_upload_options($file_name)
    {   
        //upload an image options
        $config = array();
        $config['file_name'] = $file_name;
        $config['upload_path'] = './upload/images';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']      = '0';
        $config['overwrite']     = FALSE;

        return $config;
    }

} //end class
