<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">ลงทะเบียนร้องขอซ่อม</h3>
            </div>
            <div class="panel-body">
                <form id="requestForm" method="post" class="form-horizontal ls_form" action="<?php echo base_url('/index.php/request/newRequest');?>"
                      data-bv-message="This value is not valid"
                      data-bv-feedbackicons-valid="fa fa-check"
                      data-bv-feedbackicons-invalid="fa fa-bug"
                      data-bv-feedbackicons-validating="fa fa-refresh"
                      enctype="multipart/form-data">

                    <div class="form-group">
                        <label class="col-lg-3 control-label">เรื่องการแจ้งซ้อม</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control" name="work_name" placeholder="ระบุเรื่องที่ต้องการซ่อม" required data-bv-notempty-message="กรุณาระบุเรื่องที่ต้องการซ่อม" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-lg-3 control-label">รายละเอียดงาน</label>

                        <div class="col-lg-6">
                            <textarea class="animatedTextArea form-control" id="bio" name="work_detail"
                                      placeholder="รายละเอียดของงาน"></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-lg-3 control-label">สถานที่</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control" name="place_name" placeholder="ระบุสถานที่" required data-bv-notempty-message="กรุณาระบุสถานที่" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-lg-3 control-label">ประเภทปัญหา</label>
                        <div class="col-lg-6">
                            <select id="select-problem" class="selectpicker" placeholder="เลือกแผนก..." name="problem_id" required data-bv-notempty-message="The last name is required and cannot be empty">
                                <?php
                                    foreach($problem_list as $value) {
                                        ?>
                                        <option value="<?php echo $value['problem_id'] ?>"><?php echo $value['problem_name'] ?></option>
                                        <?php
                                    }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-lg-3 control-label">อัพโหลดรูปภาพ</label>
                        <div class="col-lg-6">
                            <input id="file-3" name="userfile[]" type="file" class="file" multiple=true data-preview-file-type="any">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-lg-9 col-lg-offset-3">
                            <button type="submit" class="btn btn-primary" id="confirm">ยืนยัน</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!--selectize Library start-->
<script src="<?php echo base_url('assets/js/selectize.min.js');?>"></script>
<!--selectize Library End-->
<!--bootstrap validation Library Script Start-->
<script src="<?php echo base_url('assets/js/bootstrapvalidator/bootstrapValidator.js');?>"></script>
<!--bootstrap validation Library Script End-->
<script>
    // $("#confirm").click(function(){
    //     bootbox.confirm("คุณต้องการบันทึกข้อมูลหรือไม่?", function(result) {
    //         var data ="Confirm result: "+result;
    //         if (result) {
    //             $('form').submit();
    //         }
    //     });
    // });
    var eventHandler = function (name) {
        return function () {
            /*console.log(name, arguments);*/
        };
    };
    $(document).ready(function(){
        $("#test").click(function() {
            console.log($('#file-3')[0].files);

        })
        $("#tel").mask("(999) 999-9999");
        var $select = $('#select-department').selectize({
            create: false,
            onChange: eventHandler('onChange'),
            onItemAdd: eventHandler('onItemAdd'),
            onItemRemove: eventHandler('onItemRemove'),
            onOptionAdd: eventHandler('onOptionAdd'),
            onOptionRemove: eventHandler('onOptionRemove'),
            onDropdownOpen: eventHandler('onDropdownOpen'),
            onDropdownClose: eventHandler('onDropdownClose'),
            onInitialize: eventHandler('onInitialize')
        });
        var $select2 = $('#select-problem').selectize({
            create: false,
            onChange: eventHandler('onChange'),
            onItemAdd: eventHandler('onItemAdd'),
            onItemRemove: eventHandler('onItemRemove'),
            onOptionAdd: eventHandler('onOptionAdd'),
            onOptionRemove: eventHandler('onOptionRemove'),
            onDropdownOpen: eventHandler('onDropdownOpen'),
            onDropdownClose: eventHandler('onDropdownClose'),
            onInitialize: eventHandler('onInitialize')
        });
        $('#requestForm').bootstrapValidator();
        $("#file-3").fileinput({
            showCaption: true,
            browseClass: "btn btn-ls",
            showUpload: false
        });
    })
</script> 