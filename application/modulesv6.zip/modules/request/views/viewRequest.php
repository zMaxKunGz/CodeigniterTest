 
 
    <div id="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <!--Top header start-->
                    <h3 class="ls-top-header">รายละเอียดการแจ้ง</h3>
                    <!--Top header end -->

                    <!--Top breadcrumb start -->
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i></a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">รายละเอียดการแจ้ง</li>
                    </ol>
                    <!--Top breadcrumb start -->
                </div>
            </div>
            <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">รายละเอียดการแจ้ง</h3>
                            </div>
                            <div class="panel-body">
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">เรื่อง</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['work_name']; ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">ผู้แจ้ง</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['staff_name']; ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">รายละเอียดงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['work_description']; ?></label>
                                        </div>
                                    </div>
                                </div>


                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">วันที่แจ้ง</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['inform_date']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">ประเภทการซ่อม</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['problem_name']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">แผนก</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['department_name']; ?></label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">สถานะของงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo ($work['work_status'] == 2) ? 'ไม่อนุมัติ':$work['work_status_name']; ?></label>
                                        </div>
                                    </div>
                                </div> 
                                <?php
                                if ($work['work_status'] == 1) {
                                ?>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">ผู้รับผิดชอบงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $staff['staff_name']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">คำอธิบายงาน</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['work_detail']; ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ls_divider">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">วันที่แล้วเสร็จ</label>
                                        <div class="col-md-9">
                                        <label class=" control-label"><?php echo $work['duedate'];; ?></label>
                                        </div>
                                    </div>
                                </div> 
                                <?php    
                                }
                                ?>
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">รูปภาพ</h3>
                            </div>
                            <div class="panel-body">
                                <?php 
                                foreach ($imageList as $value) {    
                                ?>
                                <div class="col-md-12">
                                    <img src="<?php echo base_url($value['image_location'])?>" style="max-width:100%;max-height:100%;">
                                </div> 
                                <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <a href="<?php echo site_url('request/') ?>"><div align="center"><button class="btn ls-red-btn"><i class="fa fa-backward"></i> กลับหน้าหลัก </button></div></a>
                </div>

                <div class="row">
                    <br>
                </div>
        </div>
    </div>



</section>
  
</div>
 