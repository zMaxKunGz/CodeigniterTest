<div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title">ลงทะเบียนผู้ร้องขอซ่อม</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                    <div class="col-md-12">
                                        <form id="formid2" enctype="multipart/form-data" class="formular form-horizontal ls_form" method="post" action="<?php echo base_url('/index.php/request/newRequest');?>">
                                            <div id="wizard" class="swMain">
                                                <ul>
                                                    <li>
                                                        <a href="#step-Login">
                                                            <span class="stepNumber">1</span>
                                                            <span class="stepDesc">
                                                                Step 1<br/>
                                                                <small>ลงทะเบียนผู้ร้องขอซ่อม</small>
                                                            </span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#step-user">
                                                            <span class="stepNumber">2</span>
                                                            <span class="stepDesc">
                                                                Step 2<br/>
                                                                <small>ข้อมูลการแจ้งซ่อม</small>
                                                            </span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#step-bio">
                                                            <span class="stepNumber">3</span>
                                                            <span class="stepDesc">
                                                                Step 3<br/>
                                                                <small>เสร็จสิ้นการแจ้งซ่อม</small>
                                                            </span>
                                                        </a>
                                                    </li>
                                                    <!-- <li>
                                                        <a href="#step-Agreement">
                                                            <span class="stepNumber">4</span>
                                                            <span class="stepDesc">
                                                                Step 4<br/>
                                                                <small>Agreement</small>
                                                            </span>
                                                        </a>
                                                    </li> -->
                                                </ul>
                                                <div id="step-Login">
                                                    <h2 class="StepTitle">รายละเอียดการแจ้งซ่อม</h2>

                                                    <div class="container-fluid">
                                                        <div class="row ">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">ชื่อ-นามสกุล</label>

                                                                <div class="col-md-10">
                                                                    <input type="text"
                                                                           class="form-control validate[required] text-input"
                                                                           id="username" name="name" required placeholder="ชื่อ นามสกุล" data-bv-notempty-message="The first name is required and cannot be empty">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">แผนก: </label>

                                                                <div class="col-md-10">
                                                                <div class="control-group">
                                                                    <select id="select-country" class="demo-default" placeholder="เลือกแผนก..." name="dept">
                                                                        <option value="">เลือกแผนก...</option>
                                                                        <?php
                                                                            foreach($dept_list as $value) {
                                                                                ?>
                                                                                <option value="<?php echo $value['department_id'] ?>"><?php echo $value['department_name'] ?></option>
                                                                                <?php
                                                                            }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row ">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">เบอร์ติดต่อ : </label>

                                                                <div class="col-md-10">
                                                                    <input placeholder="เบอร์โทร" value=""
                                                                           class="form-control validate[required] text-input"
                                                                           type="text" name="tel" id="tel"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row ">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">อีเมลล์: </label>

                                                                <div class="col-md-10">
                                                                    <input placeholder="อีเมลล์" value=""
                                                                           class="form-control validate[required] text-input"
                                                                           type="email" name="email" id="email"/>
                                                                </div>
                                                            </div>
                                                        </div>


 


                                                    </div>
                                                </div>
                                                <div id="step-user" >
                                                    <h2 class="StepTitle">รายละเอียดการแจ้งซ่อม</h2>

                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label"> เรื่องการแจ้งซ่อม </label>

                                                                <div class="col-md-10">
                                                                    <input type="text"
                                                                           class="form-control validate[required] text-input" id="name1"
                                                                           name="work_name" placeholder="ระบุชื่องาน">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label"> รายละเอียด </label>
                                                                <div class="col-md-10">
                                                                <input type="text"
                                                                           class="form-control validate[required] text-input" id="name2"
                                                                           name="work_description" placeholder="รายละเอียดงาน">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">ประเภทปัญหา: </label>

                                                                <div class="col-md-10">
                                                                <div class="control-group">
                                                                    <select id="select-country" class="demo-default selectized" placeholder="ประเภทปัญหา..." name="problem">
                                                                        <option value="">เลือกปัญหา...</option>
                                                                        <?php
                                                                            foreach($problem_list as $value) {
                                                                                ?>
                                                                                <option value="<?php echo $value['problem_id'] ?>"><?php echo $value['problem_name'] ?></option>
                                                                                <?php
                                                                            }
                                                                        ?>
                                                                        
                                                                    </select>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </div>                                                        
                                                        <div class="row">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label"> อัพโหลดรูปภาพ </label>
                                                            
                                                                <div class="col-md-10">
                                                                    <div class="form-group">
                                                                        <div class="col-md-10   ls-group-input">

                                                                            <input id="file-3" name="userfile[]" type="file" class="file" multiple=true data-preview-file-type="any">

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group">
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <!-- <div class="row">
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label"> วันที่แจ้งซ่อม </label>

                                                                <div class="col-md-10">
                                                                    <input placeholder="someone@nowhere.com" value=""
                                                                           class="validate[required,custom[email]] form-control"
                                                                           type="text" name="email" id="email1"/>
                                                                </div>
                                                            </div>
                                                        </div> -->
                                                        
                                                    
                                                </div>
                                                <div id="step-bio">


                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <h2 class="StepTitle">วันที่แจ้งซ่อม</h2>
                                                          
                                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                                                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                                                    Ut enim ad minim veniam,
                                                                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                                                    commodo consequat.
                                                                    Duis aute irure dolor in reprehenderit in voluptate velit esse
                                                                    cillum dolore eu fugiat nulla pariatur.
                                                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                                                    officia deserunt mollit anim id est laborum.
                                                                </p>
                                                        </div>

 
                                                    </div>
                                                </div>
                                                 
                                            </div>
                                            <!-- End SmartWizard Content -->


                                        </form>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

    
        
    <!--Form Wizard CSS Start-->
    <script src="<?php echo base_url('assets/js/jquery.smartWizard.js');?>"></script>
    <!--Form Wizard CSS End-->
        <!--selectize Library start-->
        <script src="<?php echo base_url('assets/js/selectize.min.js');?>"></script>
    <!--selectize Library End-->

    <!--Select & Tag demo start-->
    <script src="<?php echo base_url('assets/js/pages/selectTag.js');?>"></script>
    <!--Select & Tag demo end-->

    <script>
        $(document).ready(function(){
            $("#file-3").fileinput({
                showCaption: true,
                browseClass: "btn btn-ls",
                fileType: "jpg",
                'showUpload': false
            });

            $('#wizard').smartWizard({
                // Properties
                selected: 0,  // Selected Step, 0 = first step
                keyNavigation: true, // Enable/Disable key navigation(left and right keys are used if enabled)
                enableAllSteps: true,  // Enable/Disable all steps on first load
                transitionEffect: 'fade', // Effect on navigation, none/fade/slide/slideleft
                contentURL: null, // specifying content url enables ajax content loading
                contentURLData: null, // override ajax query parameters
                contentCache: true, // cache step contents, if false content is fetched always from ajax url
                cycleSteps: false, // cycle step navigation
                enableFinishButton: false, // makes finish button enabled always
                hideButtonsOnDisabled: false, // when the previous/next/finish buttons are disabled, hide them instead
                errorSteps: [],    // array of step numbers to highlighting as error steps
                labelNext: 'Next', // label for Next button
                labelPrevious: 'Previous', // label for Previous button
                labelFinish: 'Finish',  // label for Finish button
                noForwardJumping: false,
                ajaxType: 'POST',
                // Events
                onLeaveStep: null, // triggers when leaving a step
                onShowStep: null,  // triggers when showing a step
                onFinish: function() {
                    $('#formid2').submit();
                },  // triggers when Finish button is clicked
                includeFinishButton: true   // Add the finish button
            });

        })
    </script>