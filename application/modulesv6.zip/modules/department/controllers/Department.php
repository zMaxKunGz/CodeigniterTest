<?php
defined('BASEPATH') or exit('No direct script access allowed');

////require_once APPPATH . '/modules/license/controllers/License.php';

class Department extends MX_Controller
{

    public function __construct()
    {
        parent::__construct();
       // $this->load->module('construction/Construction_license');
    }

    public function index()
    {
        $data['content'] = "department/worklist";
        $this->load->view('header/index', $data);
    }

    public function view()
    {
        $data['content'] = "departmentApprove/view";
        $this->load->view('header/index', $data);
    }


    public function approve()
    {
        $data['content'] = "departmentApprove/view";
        $this->load->view('header/index', $data);
    }
 
} //end class
